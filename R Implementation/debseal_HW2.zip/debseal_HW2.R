### R code from vignette source 'C:/Users/debpriya.seal/Documents/debseal_HW2.Rnw'

